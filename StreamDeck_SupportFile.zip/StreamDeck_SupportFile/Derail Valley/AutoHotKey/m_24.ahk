#Requires AutoHotkey v2.0
#SingleInstance Ignore

SetKeyDelay -1, -1
SendMode "Input"

; -----------------------------
; パス取得（スクリプトと同じフォルダ）
; -----------------------------
folder := A_ScriptDir
runFile := folder "\HandBrake_ScriptRun.ini"

; -----------------------------
; 手順1：ロック取得
; -----------------------------
retryCount := 0

Loop
{
    value := IniRead(runFile, "LOCK", "running", 0)

    if (value = "0")
    {
        IniWrite 1, runFile, "LOCK", "running"
        break
    }
    else
    {
        retryCount++
        if (retryCount >= 3)
            ExitApp

        Sleep 500
    }
}

; -----------------------------
; 手順2：手ブレーキ操作
; -----------------------------
Loop 24
{
    Send "m"
    Sleep 80   ; 80ms待機（連打間隔）
}

; -----------------------------
; 手順3：ロック解除
; -----------------------------
IniWrite 0, runFile, "LOCK", "running"

ExitApp
