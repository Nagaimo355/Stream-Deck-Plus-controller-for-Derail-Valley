#Requires AutoHotkey v2.0
#SingleInstance Ignore

SetKeyDelay -1, -1
SendMode "Input"

; -----------------------------
; パス取得（スクリプトと同じフォルダ）
; -----------------------------
folder := A_ScriptDir
runFile := folder "\DM3_GearScriptRun.ini"
gearFile := folder "\DM3_GearNum.ini"

; -----------------------------
; ロック取得
; -----------------------------
retryCount := 0

Loop
{
    value := IniRead(runFile, "LOCK", "running", 0)

    if (value = "0")
    {
        IniWrite 1, runFile, "LOCK", "running"
        break
    }
    else
    {
        retryCount++
        if (retryCount >= 3)
            ExitApp

        Sleep 100
    }
}

; -----------------------------
; 現在のギア数を読み取り
; -----------------------------
gear := IniRead(gearFile, "STATE", "gear", 1)

if !IsInteger(gear)
    gear := 1

; -----------------------------
; スロットル・ダイナミックブレーキ全解（ダイアル摩耗低減が目的）
; -----------------------------
Loop 8
{
    Send "t"
    Send "l"
    Sleep 80   	; 80ms待機（連打間隔）
}
    Sleep 160   ; 160ms待機

; -----------------------------
; ギアアップ操作
; -----------------------------
if (gear = 1)
{
    Send "{NumpadDiv}"
}
else if (gear = 2)
{
    Send "{NumpadDiv}"
}
else if (gear = 3)
{
    Send "{NumpadDiv}"
}
else if (gear = 4)
{
    Send "{NumpadDiv}"
}
else if (gear = 5)
{
    Send "{NumpadMult}"
    Sleep 100		; 100ms待機（連打間隔）
    Send "{NumpadMult}"
    Sleep 100		; 100ms待機（連打間隔）
    Send "{Numpad8}"
}
else if (gear = 6)
{
    Send "{NumpadMult}"
}
else if (gear = 7)
{
    Send "{NumpadDiv}"
}


; -----------------------------
; ギア数更新
; -----------------------------
if (gear <= 6)
{
    gear += 2
}
else if (gear = 7)
{
    gear++
}

IniWrite gear, gearFile, "STATE", "gear"

; -----------------------------
; ロック解除
; -----------------------------
IniWrite 0, runFile, "LOCK", "running"

ExitApp
