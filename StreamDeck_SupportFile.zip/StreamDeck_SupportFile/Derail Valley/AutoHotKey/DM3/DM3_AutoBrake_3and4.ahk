#Requires AutoHotkey v2.0
#SingleInstance Ignore

SetKeyDelay -1, -1
SendMode "Input"

; -----------------------------
; パス取得（スクリプトと同じフォルダ）
; -----------------------------
folder := A_ScriptDir
runFile := folder "\DM3_AutoBrakeScriptRun.ini"
brakeFile := folder "\DM3_AutoBrakeNum.ini"

; -----------------------------
; ロック取得
; -----------------------------
retryCount := 0

Loop
{
    value := IniRead(runFile, "LOCK", "running", 0)

    if (value = "0")
    {
        IniWrite 1, runFile, "LOCK", "running"
        break
    }
    else
    {
        retryCount++
        if (retryCount >= 3)
            ExitApp

        Sleep 100
    }
}

; -----------------------------
; 現在のギア数を読み取り
; -----------------------------
brake := IniRead(brakeFile, "STATE", "brake", 1)

if !IsInteger(brake)
    brake := 1

; -----------------------------
; ブレーキアップ操作、3:常用まで
; -----------------------------
if (brake = 4)
{
    Loop 4
    {
    Send "u"
    Sleep 80   	; 80ms待機（連打間隔）
    }
}
else if (brake = 3)
{
    Send "u"
}
else if (brake = 2)
{
    Send "u"
}
else if (brake = 1)
{
    Loop 2
    {
    Send "u"
    Sleep 80   	; 80ms待機（連打間隔）
    }
}

; -----------------------------
; ブレーキ数更新
; -----------------------------
if (brake >= 4)
{
    brake := 4
}
else if (brake = 3)
{
    brake++
}
else if (brake = 2)
{
    brake++
}
else if (brake = 1)
{
    brake += 2
}

IniWrite brake, brakeFile, "STATE", "brake"

; -----------------------------
; ロック解除
; -----------------------------
IniWrite 0, runFile, "LOCK", "running"

ExitApp
