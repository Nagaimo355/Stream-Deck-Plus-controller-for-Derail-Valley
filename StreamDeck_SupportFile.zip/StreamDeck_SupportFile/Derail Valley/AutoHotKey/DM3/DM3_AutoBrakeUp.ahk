#Requires AutoHotkey v2.0
#SingleInstance Ignore

SetKeyDelay -1, -1
SendMode "Input"

; -----------------------------
; パス取得（スクリプトと同じフォルダ）
; -----------------------------
folder := A_ScriptDir
runFile := folder "\DM3_AutoBrakeScriptRun.ini"
brakeFile := folder "\DM3_AutoBrakeNum.ini"

; -----------------------------
; ロック取得
; -----------------------------
retryCount := 0

Loop
{
    value := IniRead(runFile, "LOCK", "running", 0)

    if (value = "0")
    {
        IniWrite 1, runFile, "LOCK", "running"
        break
    }
    else
    {
        retryCount++
        if (retryCount >= 3)
            ExitApp

        Sleep 100
    }
}

; -----------------------------
; 現在のギア数を読み取り
; -----------------------------
brake := IniRead(brakeFile, "STATE", "brake", 1)

if !IsInteger(brake)
    brake := 1

; -----------------------------
; ブレーキアップ操作、3:常用まで
; -----------------------------
if (brake = 1)
{
    Send "u"
}
else if (brake = 2)
{
    Send "u"
}

; -----------------------------
; ブレーキ数更新
; -----------------------------
if (brake >= 4)
{
    brake := 4
}
else if (brake = 3)
{
    brake := 3
}
else if (brake <= 2)
{
    brake++
}

IniWrite brake, brakeFile, "STATE", "brake"

; -----------------------------
; ロック解除
; -----------------------------
IniWrite 0, runFile, "LOCK", "running"

ExitApp
