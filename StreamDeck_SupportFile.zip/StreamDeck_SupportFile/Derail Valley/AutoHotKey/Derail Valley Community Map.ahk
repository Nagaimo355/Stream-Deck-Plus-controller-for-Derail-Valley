﻿#SingleInstance Force
SetTitleMatchMode 2

if WinExist("Derail Valley Community Map")
{
    WinActivate
}
else
{
    Run '"C:\Program Files (x86)\Microsoft\Edge\Application\msedge_proxy.exe" --profile-directory=Default --app-id=cdjglcejnjeegkijmeoadgffkjcjkjkp --app-url=https://pyronicampt.github.io/DV-Community-Map/ --app-launch-source=4'
}
