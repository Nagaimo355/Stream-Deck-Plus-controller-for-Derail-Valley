#Requires AutoHotkey v2.0
#SingleInstance Ignore

SetKeyDelay -1, -1
SendMode "Input"

; -----------------------------
; パス取得（スクリプトと同じフォルダ）
; -----------------------------
folder := A_ScriptDir
runFile := folder "\DM1U_GearScriptRun.ini"
gearFile := folder "\DM1U_GearNum.ini"

; -----------------------------
; ロック取得
; -----------------------------
retryCount := 0

Loop
{
    value := IniRead(runFile, "LOCK", "running", 0)

    if (value = "0")
    {
        IniWrite 1, runFile, "LOCK", "running"
        break
    }
    else
    {
        retryCount++
        if (retryCount >= 3)
            ExitApp

        Sleep 100
    }
}

; -----------------------------
; 現在のギア数を読み取り
; -----------------------------
gear := IniRead(gearFile, "STATE", "gear", 0)

if !IsInteger(gear)
    gear := 0

; -----------------------------
; スロットル全解（ダイアル摩耗低減が目的）
; -----------------------------
Loop 6
{
    Send "t"
    Sleep 80   	; 80ms待機（連打間隔）
}

; -----------------------------
; ギアダウン操作
; -----------------------------
if (gear >= 2)
{
    Loop 2
    {
        Send "{Numpad8}"
        Sleep 80   	; 80ms待機（連打間隔）
    }
}
else if (gear = 1)
{
    Send "{Numpad8}"
}
else if (gear = 0)
{
    Loop 7
    {
        Send "{Numpad8}"
        Sleep 80   	; 80ms待機（連打間隔）
    }
}

; -----------------------------
; ギア数更新
; -----------------------------
if (gear >= 2)
{
    gear -= 2
}
else if (gear = 1)
{
    gear--
}

IniWrite gear, gearFile, "STATE", "gear"

; -----------------------------
; ロック解除
; -----------------------------
IniWrite 0, runFile, "LOCK", "running"

ExitApp
