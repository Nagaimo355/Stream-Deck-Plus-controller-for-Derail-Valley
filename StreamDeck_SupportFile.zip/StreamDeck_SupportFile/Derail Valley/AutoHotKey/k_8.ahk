#Requires AutoHotkey v2.0
#SingleInstance Ignore

SetKeyDelay -1, -1
SendMode "Input"

Loop 8
{
    Send "k"
    Sleep 80   ; 80ms待機（連打間隔）
}
